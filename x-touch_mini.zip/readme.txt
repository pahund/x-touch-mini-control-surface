=======================================================
Ableton Live Control Surface for Behringer X-Touch Mini
=======================================================

Version 0.0.1

To control Ableton Live with the Behringer X-Touch Mini USB MIDI controller, move the
directory "X-Touch_Mini" in this zip file over to your MIDI Remote Scripts directory
(a subdirectory of your Live installation).

For more detailed instructions, see Ableton's knowledge base:

https://help.ableton.com/hc/articles/209072009-Installing-Third-Party-Control-Surfaces

